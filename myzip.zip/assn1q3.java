import automaticproofing.*;

public class assn1q3 {
	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("please make sure that you supply only 1 command line argument, and surrounded by double quotes!");
			System.out.println("for example [p] seq [p] should be written as " + "\"[p] seq [p]\"");
			System.exit(0);
		}
		FormulaBuilder fb = new FormulaBuilder(); 
		ProblemSolver pb = ProblemSolver.getInstance();
		
		SolutionTree.clear();
		try {
			Pair<Boolean, SolutionTree> ret = pb.executeproof(fb.produceInitialSequent(args[0]));
			System.out.println(ret.getFirst());
			if (ret.getFirst()) {
				ret.getSecond().printProof();
				System.out.println("QED.");
			}
		} catch (Error e) {
			System.out.println(false);
			// System.out.println(e.getMessage());
		}
	}
}
