package automaticproofing;


/**
 * note that the problem should be implemented using composite pattern, but
 * for this problem, that isn't necessary
 * @author harry
 *
 */

public class Formula {
	private Formula left;
	private Formula right;
	private String connection;
	private String atom;
	private boolean isatom = false;
	// constructor for the a single formula 
	public Formula(String atom) {
		this.left = this.right = null;
		this.atom = atom;
		this.connection = "";
		this.isatom = true;
	}
	
	public boolean isAtom() {
		return this.isatom;
	}
	
	
	// the constructor for a formula that is a combination of two formulas
	public Formula(String connection, Formula left, Formula right) {
		this.left = left;
		this.right = right;
		this.connection = connection;
		this.atom = "";
		this.isatom = false;
	}
	
	public String getAtom() {
		return this.atom;
	}
	
	public String getConnection() {
		return this.connection;
	}
	
	public Formula getLeft() {
		return left;
	}
	
	public Formula getRight() {
		return right;
	}
	
	public String toString() {
		return printFormula(this).toString();
	}
	
	private StringBuilder printFormula(Formula fm) {
		StringBuilder sb = new StringBuilder();
		if (fm == null) return sb;
		if (!fm.isAtom()) {
			sb.append("(");
		}
		sb.append(printFormula(fm.getLeft()));
		if (fm.isAtom()) {
			sb.append(fm.getAtom());
		} else {
			sb.append(" ");
			sb.append(fm.getConnection());
			sb.append(" ");
		}
		sb.append(printFormula(fm.getRight()));
		if (!fm.isAtom()) {
			sb.append(")");
		}
		return sb;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (!(obj instanceof Formula)) return false;
		Formula fm = (Formula) obj;
		return ProblemSolver.formulaEqual(this, fm);
	}
}

