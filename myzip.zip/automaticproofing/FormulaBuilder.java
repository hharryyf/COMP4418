package automaticproofing;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/*
 this class is in charge of parsing the original string to two groups 
 of formulas and create the initial sequent
*/

public class FormulaBuilder {
	
	public Sequent produceInitialSequent(String syntex) {
		if (syntex == null || syntex.length() == 0) {
			throw new Error("empty formulas warning!");
		}
		System.out.println(syntex);
		Pair<List<List<String>>, List<List<String>>> p = produceFormulaString(syntex);
		Sequent seq = new Sequent();
		boolean hasempty = false;
		for (List<String> ss : p.getFirst()) {
			// System.out.println(convertToPrefix(ss));
			Formula fm = produceFormula(ss);
			if (fm == null || fm.isAtom() && fm.getAtom().compareTo("") == 0) {
				hasempty = true;
				continue;
			}
			seq.addLeft(fm);
		}
		
		if (hasempty && p.getFirst().size() >= 2) {
			throw new Error("empty formulas warning!");
		}
		
		hasempty = false;
		for (List<String> ss : p.getSecond()) {
			// System.out.println(convertToPrefix(ss));
			Formula fm = produceFormula(ss);
			if (fm == null || fm.isAtom() && fm.getAtom().compareTo("") == 0) {
				hasempty = true;
				continue;
			}
			seq.addRight(fm);
		}
		
		if (hasempty && p.getSecond().size() >= 2) {
			throw new Error("empty formulas warning!");
		}
		return seq;
	}
	
	// produce a single formula
	public Formula produceFormula(List<String> input) {
		if (input == null || input.size() == 0) {
			return new Formula("");
		}
		
		if (input.size() == 1 && input.get(0).length() == 0) {
			return new Formula("");
		}
		
		// build a prefix tree from infix expression
		return buildFromInfix(convertToPrefix(input));
	}
	// build the formula from the reverse polish notation
	
	private Formula buildFromInfix(List<String> prefix) {
		// System.out.println(prefix);
		Stack<Formula> st = new Stack<>();
		for (String str : prefix) {
			if (getPriority(str) == -1) {
				st.push(new Formula(str));
			} else {
				if (getPriority(str) == 3) {
					if (st.empty()) {
						throw new Error("the given sequent is invalid! please make sure the bracket is balance");
					}
					Formula fm = new Formula(str, null, st.pop());
					st.push(fm);
				} else {
					if (st.size() < 2) {
						throw new Error("the given sequent is invalid! please make sure the bracket is balance");
					}
					Formula f1 = st.pop();
					Formula f2 = st.pop();
					Formula fm = new Formula(str, f2, f1);
					st.push(fm);
				}
			}
		}
		
		if (st.size() != 1) {
			throw new Error("the given sequent is invalid! please make sure the bracket is balance");
		}
		
		return st.pop();
	}
	// remove the double negation before converting the original expression
	// to reverse polish notation
	private List<String> removeDoubleNegation(List<String> formula) {
		List<String> ret = new LinkedList<>();
		Stack<Integer> stack = new Stack<>();
		boolean meetatom = false;
		int i;
		for (i = 0; i < formula.size(); i++) {
			if (i == formula.size() - 1 && getPriority(formula.get(i)) == 3) {
				throw new Error("the given sequent is invalid! please make sure the bracket is balance");
			}
			
			// double negation occurs
			if (getPriority(formula.get(i)) == 3 && getPriority(formula.get(i + 1)) == 3) {
				ret.add(formula.get(i));
				ret.add("(");
				meetatom = false;
				stack.add(0);
			} else {
				ret.add(formula.get(i));
				if (!stack.empty()) {
					if (formula.get(i).compareTo("(") == 0) {
						int tmp = stack.pop();
						stack.push(tmp + 1);
					} else if (formula.get(i).compareTo(")") == 0) {
						int tmp = stack.pop();
						tmp--;
						stack.push(tmp);
					} else if (getPriority(formula.get(i)) == -1) {
						meetatom = true;
					}
					
					while (!stack.empty() && stack.peek() == 0 && meetatom) {
						ret.add(")");
						stack.pop();
					}
				} else {
					meetatom = false;
				}
			}
		}
		// System.out.println(ret);
		return ret;
	}
	// convert the formula to reverse polish notation using the 
	// popular algorithm with two stacks
	public List<String> convertToPrefix(List<String> fml) {
		List<String> formula = removeDoubleNegation(fml);
		List<String> ret = new LinkedList<String>();
		Stack<String> stack = new Stack<>();
		int i;
		for (i = 0 ; i < formula.size(); i++) {
			String str = formula.get(i);
			if (getPriority(str) == -1) {
				if (str.compareTo("(") == 0) {
					stack.push(str);
				} else if (str.compareTo(")") == 0) {
					 while (!stack.isEmpty() && stack.peek().compareTo("(") != 0) { 
		                    ret.add(stack.pop()); 
		             }
		             stack.pop(); 
				} else {
					ret.add(str);
				}
			} else {
				while (!stack.isEmpty() && getPriority(str) <= getPriority(stack.peek())) {
					ret.add(stack.pop()); 
                }
                stack.push(str);
			}
			
		}
		
		while (!stack.isEmpty()){  
            ret.add(stack.pop()); 
         } 
		return ret;
	}
	// set the priority of the operators
	private int getPriority(String str) {
		if (str.compareTo("neg") == 0) return 3;
		if (str.compareTo("and") == 0) return 2;
		if (str.compareTo("or") == 0) return 2;
		if (str.compareTo("imp") == 0) return 1;
		if (str.compareTo("iff") == 0) return 1;
		return -1;
	}
	
	/**
	 * 
	 * @param a string input
	 * @return two lists of parsed strings
	 */
	public Pair<List<List<String>>, List<List<String>>> produceFormulaString(String input) {
		Pair<List<List<String>>, List<List<String>>> p = new Pair<>();
		List<List<String>> ret = new LinkedList<>();
		List<String> current = new LinkedList<>();
		StringBuilder sb = new StringBuilder();
		int i;
		boolean shouldrecord = false, afterseq = false;
		for (i = 0 ; i < input.length(); i++) {
			char ch = input.charAt(i);
			if (ch == ')') {
				if (sb.length() != 0) {
					current.add(sb.toString());
				} else if (current.get(current.size() - 1).compareTo("(") == 0) {
					current.add(sb.toString());
				}
				sb = new StringBuilder();
				sb.append(ch);
				current.add(sb.toString());
				sb = new StringBuilder();
			} else if (ch == '(') {
				if (sb.length() != 0) {
					current.add(sb.toString());
				}
				sb = new StringBuilder();
				sb.append(ch);
				current.add(sb.toString());
				sb = new StringBuilder();
			} else if (ch == ' ') {
				if (sb.length() != 0) {
					current.add(sb.toString());
				}
				sb = new StringBuilder();
			} else if (ch == ',') {
				if (sb.length() != 0) {
					current.add(sb.toString());
				} else if (current.size() == 0) {
					// empty clause
					current.add(sb.toString());
				}
				ret.add(current);
				sb = new StringBuilder();
				current = new LinkedList<>();
			} else if (ch == '[') {
				shouldrecord = true;
			} else if (ch == ']') {
				shouldrecord = false;
				if (sb.length() != 0) {
					current.add(sb.toString());
				} else if (current.size() == 0) {
					current.add(sb.toString());
				}
				ret.add(current);
				if (afterseq) {
					p.setSecond(ret);
				} else {
					afterseq = true;
					shouldrecord = false;
					p.setFirst(ret);
				}
				
				ret = new LinkedList<>();
				sb = new StringBuilder();
				current = new LinkedList<>();
			} else {
				if (shouldrecord) {
					sb.append(ch);
				}
			}
		}
		return p;
	}
}

