package automaticproofing;

import java.util.LinkedList;

public class P1 implements Rule {
	
	private String name = new String("Rule P1");
	
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		LinkedList<Formula> L = seq.getLeft();
		LinkedList<Formula> R = seq.getRight();
		SolutionTree t = new SolutionTree();
		for (Formula fm : L) {
			if (!fm.isAtom()) {
				return new Pair<Boolean, SolutionTree>(false, null);
			}
		}
		
		for (Formula fm : R) {
			if (!fm.isAtom()) {
				return new Pair<Boolean, SolutionTree>(false, null);
			}
		}
		
		for (Formula fm : L) {
			if (R.contains(fm) && fm.isAtom()) {
				t.setRule(name);
				t.setSequent(seq);
				return new Pair<Boolean, SolutionTree>(true, t);
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}
	
}

