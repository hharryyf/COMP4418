package automaticproofing;

import java.util.Iterator;

/**
 * if a, b  |- c, d then b |- ~a, c, d
 * @author harry
 * this rule basically means where there's a negation on the RHS, we can move that negation to the LHS
 */


public class P2a implements Rule {

	private String name = new String("Rule P2a");
	
	public String getName() {
		return this.name;
	}
	
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		ProblemSolver fb = ProblemSolver.getInstance();
		Iterator<Formula> iter = seq.getRight().iterator();
		SolutionTree t = new SolutionTree();
		t.setRule(name);
		t.setSequent(seq);
		while (iter.hasNext()) {
			Formula fm = iter.next();
			if (fm.getConnection().compareTo("neg") == 0) {
				Sequent dup = seq.duplicate();
				dup.getRight().remove(fm);
				dup.addLeft(fm.getRight());
				Pair<Boolean, SolutionTree> ret = fb.executeproof(dup);
				if (ret.getFirst() == true) {
					t.setLeft(ret.getSecond());
					return new Pair<Boolean, SolutionTree>(true, t);
				}
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}
	
}

