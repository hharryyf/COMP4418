package automaticproofing;

import java.util.Iterator;

/**
 * if a, b  |- c, d then a, b, ~d |- c
 * @author harry
 * this rule basically means where there's a negation on the LHS, we can move that negation to the RHS
 */

public class P2b implements Rule {

	private String name = new String("Rule P2b");
	
	public String getName() {
		return this.name;
	}
		
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		ProblemSolver fb = ProblemSolver.getInstance();
		Iterator<Formula> iter = seq.getLeft().iterator();
		SolutionTree t = new SolutionTree();
		t.setRule(name);
		t.setSequent(seq);
		while (iter.hasNext()) {
			Formula fm = iter.next();
			if (fm.getConnection().compareTo("neg") == 0) {
				Sequent dup = seq.duplicate();
				dup.getLeft().remove(fm);
				dup.addRight(fm.getRight());
				Pair<Boolean, SolutionTree> ret = fb.executeproof(dup);
				if (ret.getFirst()) {
					t.setLeft(ret.getSecond());
					return new Pair<Boolean, SolutionTree>(true, t);
				}
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}

}

