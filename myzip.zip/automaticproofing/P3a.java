package automaticproofing;

import java.util.Iterator;

/**
 * if a |- b, c, d and a |- b, e, d then a |- b, d, c ^ e
 * @author harry
 *
 */

public class P3a implements Rule {
	
	private String name = "Rule P3a";
	
	public String getName() {
		return this.name;
	}
	
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		ProblemSolver fb = ProblemSolver.getInstance();
		Iterator<Formula> iter = seq.getRight().iterator();
		SolutionTree t = new SolutionTree();
		t.setRule(name);
		t.setSequent(seq);
		while (iter.hasNext()) {
			Formula fm = iter.next();
			if (fm.getConnection().compareTo("and") == 0) {
				Sequent dup1 = seq.duplicate();
				dup1.getRight().remove(fm);
				Sequent dup2 = seq.duplicate();
				dup2.getRight().remove(fm);
				dup1.addRight(fm.getLeft());
				dup2.addRight(fm.getRight());
				Pair<Boolean, SolutionTree> ret1 = fb.executeproof(dup1);
				Pair<Boolean, SolutionTree> ret2 = fb.executeproof(dup2);
				if (ret1.getFirst() && ret2.getFirst()) {
					t.setLeft(ret1.getSecond());
					t.setRight(ret2.getSecond());
					return new Pair<Boolean, SolutionTree>(true, t);
				}
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}

}

