package automaticproofing;

import java.util.Iterator;

/**
 * if a |- b, c, d and e |- b, c, d then a V e |- b, c, d
 * @author harry
 *
 */

public class P4b implements Rule {

	private String name = "Rule P4b";
	
	public String getName() {
		return this.name;
	}
	
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		ProblemSolver fb = ProblemSolver.getInstance();
		Iterator<Formula> iter = seq.getLeft().iterator();
		SolutionTree t = new SolutionTree();
		t.setRule(name);
		t.setSequent(seq);
		while (iter.hasNext()) {
			Formula fm = iter.next();
			if (fm.getConnection().compareTo("or") == 0) {
				Sequent dup1 = seq.duplicate();
				dup1.getLeft().remove(fm);
				Sequent dup2 = seq.duplicate();
				dup2.getLeft().remove(fm);
				dup1.addLeft(fm.getLeft());
				dup2.addLeft(fm.getRight());
				Pair<Boolean, SolutionTree> ret1 = fb.executeproof(dup1);
				Pair<Boolean, SolutionTree> ret2 = fb.executeproof(dup2);
				if (ret1.getFirst() && ret2.getFirst()) {
					t.setLeft(ret1.getSecond());
					t.setRight(ret2.getSecond());
					return new Pair<Boolean, SolutionTree>(true, t);
				}
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}

}

