package automaticproofing;

import java.util.Iterator;

/**
 * if a, b |- c, d then a |- b imp c, d
 * @author harry
 *
 */

public class P5a implements Rule {

	private String name = "Rule P5a";
	
	public String getName() {
		return this.name;
	}
	
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		ProblemSolver fb = ProblemSolver.getInstance();
		Iterator<Formula> iter = seq.getRight().iterator();
		SolutionTree t = new SolutionTree();
		t.setRule(name);
		t.setSequent(seq);
		while (iter.hasNext()) {
			Formula fm = iter.next();
			if (fm.getConnection().compareTo("imp") == 0) {
				Sequent dup = seq.duplicate();
				dup.getRight().remove(fm);
				dup.addLeft(fm.getLeft());
				dup.addRight(fm.getRight());
				Pair<Boolean, SolutionTree> ret = fb.executeproof(dup);
				if (ret.getFirst()) {
					t.setLeft(ret.getSecond());
					return new Pair<Boolean, SolutionTree>(true, t);
				}
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}

}

