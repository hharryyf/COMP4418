package automaticproofing;

import java.util.Iterator;

public class P6b implements Rule {

	private String name = "Rule P6b";

	
	public String getName() {
		return this.name;
	}
	
	@Override
	public Pair<Boolean, SolutionTree> transform(Sequent seq) {
		ProblemSolver fb = ProblemSolver.getInstance();
		Iterator<Formula> iter = seq.getLeft().iterator();
		SolutionTree t = new SolutionTree();
		t.setRule(name);
		t.setSequent(seq);
		while (iter.hasNext()) {
			Formula fm = iter.next();
			if (fm.getConnection().compareTo("iff") == 0) {
				Sequent dup1 = seq.duplicate();
				dup1.getLeft().remove(fm);
				Sequent dup2 = seq.duplicate();
				dup2.getLeft().remove(fm);
				dup1.addLeft(fm.getLeft());
				dup1.addLeft(fm.getRight());
				dup2.addRight(fm.getRight());
				dup2.addRight(fm.getLeft());
				Pair<Boolean, SolutionTree> ret1 = fb.executeproof(dup1);
				Pair<Boolean, SolutionTree> ret2 = fb.executeproof(dup2);
				if (ret1.getFirst() && ret2.getFirst()) {
					t.setLeft(ret1.getSecond());
					t.setRight(ret2.getSecond());
					return new Pair<Boolean, SolutionTree>(true, t);
				}
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}

}

