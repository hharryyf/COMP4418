package automaticproofing;
/*
	generic pair, very convenient for this assignment
*/
public class Pair<K, V> {
	private K first;
	private V second;
	
	public Pair() {
		this.first = null;
		this.second = null;
	}
	
	public Pair(K first, V second) {
		this.first = first;
		this.second = second;
	}
	
	public K getFirst() {
		return this.first;
	}
	
	public V getSecond() {
		return this.second;
	}
	
	public void setFirst(K fs) {
		this.first = fs;
	}
	
	public void setSecond(V ss) {
		this.second = ss;
	}
	
	@Override
	public String toString() {
		return "First: " + this.first + "\n" + "Second " + this.second;
	}
}

