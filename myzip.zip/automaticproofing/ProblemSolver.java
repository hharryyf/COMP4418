package automaticproofing;

import java.util.LinkedList;
import java.util.List;

public class ProblemSolver {
	
	private static ProblemSolver instance = null;
	private List<Rule> rules;
	private ProblemSolver() {
		this.rules = new LinkedList<>();
		rules.add(new P1());
		rules.add(new P2a());
		rules.add(new P2b());
		rules.add(new P3a());
		rules.add(new P3b());
		rules.add(new P4a());
		rules.add(new P4b());
		rules.add(new P5a());
		rules.add(new P5b());
		rules.add(new P6a());
		rules.add(new P6b());
	}
	
	public static ProblemSolver getInstance() {
		if (instance == null) {
			instance = new ProblemSolver();
		} 
		
		return instance;
	}
	
	public Pair<Boolean, SolutionTree> executeproof(Sequent current) {
		// System.out.println(current);
		for (Rule rule : this.rules) {
			Pair<Boolean, SolutionTree> t = rule.transform(current);
			if (t.getFirst() == true) {
				return t;
			}
		}
		return new Pair<Boolean, SolutionTree>(false, null);
	}
	
	public static boolean formulaEqual(Formula f1, Formula f2) {
		if (f1 == f2) return true;
		if (f1 == null && f2 == null) return true;
		if (f1 == null || f2 == null) return false;
		if (f1.getAtom().compareTo(f2.getAtom()) != 0) return false;
		if (f1.getConnection().compareTo(f2.getConnection()) != 0) return false;
		return formulaEqual(f1.getLeft(), f2.getLeft()) && formulaEqual(f1.getRight(), f2.getRight());
	}
	
}

