package automaticproofing;
/* we use strategy design pattern to increase the maintainability of the code */
public interface Rule {
	public Pair<Boolean, SolutionTree> transform(Sequent seq);
}

