package automaticproofing;

import java.util.LinkedList;

public class Sequent {
	private LinkedList<Formula> left;
	private LinkedList<Formula> right;
	
	public Sequent() {
		this.left = new LinkedList<>();
		this.right = new LinkedList<>(); 
	}
	
	public LinkedList<Formula> getLeft() {
		return this.left;
	}
	
	public LinkedList<Formula> getRight() {
		return this.right;
	}
	
	public void addLeft(Formula f) {
		if (!left.contains(f)) {
			this.left.add(f);
		}
	}
	
	public void addRight(Formula f) {
		if (!right.contains(f)) {
			this.right.add(f);
		}
	}
	
	public Sequent duplicate() {
		Sequent ret = new Sequent();
		for (Formula fm : this.left) {
			ret.addLeft(fm);
		}
		
		for (Formula fm : this.right) {
			ret.addRight(fm);
		}
		
		return ret;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(this.left.toString());
		sb.append("   seq   ");
		sb.append(this.right.toString());
		return sb.toString();
	}
}

