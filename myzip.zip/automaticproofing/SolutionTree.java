package automaticproofing;

public class SolutionTree {
	private SolutionTree left, right;
	private Sequent sequent;
	private String rule;
	private static int step = 1;
	private int linenum = 0;
	public SolutionTree() {
		this.left = this.right = null;
		this.rule = "";
	}
	
	public static void clear() {
		step = 1;
	}
	
	public void setSequent(Sequent seq) {
		this.sequent = seq;
	}
	
	public void setRule(String rule) {
		this.rule = rule;
		// System.out.println(rule);
	}
	
	public Sequent getSequent() {
		return this.sequent;
	}
	
	public void setLeft(SolutionTree t) {
		this.left = t;
	}
	
	public void setRight(SolutionTree t) {
		this.right = t;
	}
	
	public void printProof() {
		fillLine(this);
		postorder(this);
	}
	
	public void setLine(int num) {
		this.linenum = num;
	}
	
	public int getLine() {
		return this.linenum;
	}
	
	private void fillLine(SolutionTree t) {
		if (t == null) return;
		fillLine(t.left);
		fillLine(t.right);
		t.setLine(step++);
	}
	
	private void postorder(SolutionTree t) {
		if (t == null) return;
		postorder(t.left);
		postorder(t.right);
		System.out.print(t.linenum + ". ");
		if (t.left != null && t.right != null) {
			System.out.println(t.sequent + "                " + t.left.getLine() + ", " + t.right.getLine() + " " + t.rule);
		} else {
			if (t.left != null) {
				System.out.println(t.sequent + "                " + t.left.getLine() + " " + t.rule);
			} else {
				System.out.println(t.sequent + "                " + t.rule);
			}
		}
	}
}

